# UD5 A3. Validación XSD.

[Ejercicio 1 XML](./Ejercicio1.xml)

[Ejercicio 1 XSD](./Ejercicio1.xsd)

[Ejercicio 2 XML](./Ejercicio2.xml)

[Ejercicio 2 XSD](./Ejercicio2.xsd)

[Ejercicio 3 XML](./Ejercicio3.xml)

[Ejercicio 3 XSD](./Ejercicio3.xsd)

[Ejercicio 4 XML](./Ejercicio4.xml)

[Ejercicio 4 XSD](./Ejercicio4.xsd)

[Ejercicio 5 XML](./Ejercicio5.xml)

[Ejercicio 5 XSD](./Ejercicio5.xsd)

[Ejercicio 6 XML](./Ejercicio6.xml)

[Ejercicio 6 XSD](./Ejercicio6.xsd)

[Ejercicio 7 XML](./Ejercicio7.xml)

[Ejercicio 7 XSD](./Ejercicio7.xsd)

[Ejercicio 8 XML](./Ejercicio8.xml)

[Ejercicio 8 XSD](./Ejercicio8.xsd)

[Ejercicio 9 XML](./Ejercicio9.xml)

[Ejercicio 9 XSD](./Ejercicio9.xsd)

[Ejercicio 10 XML](./Ejercicio10.xml)

[Ejercicio 10 XSD](./Ejercicio10.xsd)

[Atrás](../README.md)