# UD5 A3. Validación XSD. FACTURA

[Factura XML](./Factura.xml)

[Factura XSD](./Factura.xsd)

[Atrás](../README.md)